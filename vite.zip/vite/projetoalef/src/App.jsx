
import { Euzinho } from "./aiaiai"
import { Header } from "./Header"
import { Post } from "./Post"

function App() {
  return[
    <>
    <h1>hihihiha</h1>
    <img src="\src\hihihiha.png" alt="kingemote"width="150" height="100" />
    <div>
    <Euzinho />
    <Post author = "@gust8vo" content = "AKKAKAKAKAKAKAK" />
    </div>
  
    </>
  ]
}

export default App
