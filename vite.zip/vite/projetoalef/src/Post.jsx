export function Post(props){
    return(
    <div>
        <h4>{ props.author }</h4>
        <h4>{ props.content }</h4>
    </div>
    )

}