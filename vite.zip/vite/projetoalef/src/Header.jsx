import { Post } from "./Post"

export function Header(){
    return(
        < Post />

    )



}